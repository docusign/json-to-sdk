Using the API Request Builder's Node.JS program output
===================================================

1. Install and unzip the Node.JS framework files,
   including this file.
2. You will need Node.JS (at least version 8.10) and npm.
3. In the NodeJS_example directory, run:
      npm install
4. Download and overwrite the index.js file.
6. Execute the program by running
      npm start

Notes:
1. If your program includes any views, such as the embedded
   signer view, then you MUST immediately open the URL
   in a browser. It is only good for a limited time.
