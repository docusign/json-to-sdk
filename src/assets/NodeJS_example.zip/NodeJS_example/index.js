// Replace the content of this file with the Node.JS
// output from the Builder tool