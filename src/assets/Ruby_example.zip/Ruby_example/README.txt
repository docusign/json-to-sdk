Installing and running Ruby examples

Steps
1. Install this Ruby framework directory. (Done!)
2. From within the directory:
3. bundle install
4. Send an envelope via the API Request Builder. This will cause you 
   to login to the tool, and will set the access_token and account_id 
   in the example.
5. Download the example from the API Request Builder. 
   *Overwrite* the main.rb file in this directory.
6. ruby main.rb

Comments, error reports? Please use the Feedback button 
in the top navigation section of the API Request Builder.

Thank you!
