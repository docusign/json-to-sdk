Installing and running Ruby examples

Steps
1. Install this Ruby framework directory. (Done!)
2. From within the directory:
3. bundle install
4. Download the example from the JSON to SDK tool. 
   *Overwrite* the main.rb file in this directory.
5. ruby main.rb

Comments, error reports? Please use the Feedback button 
in the top navigation section of the API Request Builder.

Thank you!
