Installing and running Python examples

Steps
1. Install this Python framework directory. (Done!)
2. From within the directory:
3. pipenv install
4. Download the example from the JSON to SDK tool. 
   *Overwrite* the main.py file in this directory.
5. pipenv run python3 main.py

Notes
1. Both a Pipfile and requirements.txt files are provided.
2. The examples have only been tested with Python3

Comments, error reports? Please use the Feedback button 
in the top navigation section of the API Request Builder.

Thank you!
