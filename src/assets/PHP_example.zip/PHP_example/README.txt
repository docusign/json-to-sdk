Using the API Request Builder's Node.JS program output
===================================================

1. Install and unzip the PHP framework files,
   including this file.
2. You will need a current version of PHP and composer.
   Note that PHP needs to be enabled for command line execution.
3. In the PHP_example directory, run:
      composer install
5. Download and overwrite the index.php file.
6. Execute the program by running
      php index.php
   from the command line

Notes:
1. If your program includes any views, such as the embedded
   signer view, then you MUST immediately open the URL
   in a browser. It is only good for a limited time.
